import type React from "react"
import { Row, Col, Card, Progress, Typography, List, Tag, Statistic } from "antd"
import { BookOutlined, ClockCircleOutlined, TrophyOutlined, CalendarOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const Dashboard: React.FC = () => {
  // Sample data
  const inProgressCourses = [
    { id: 1, title: "Introduction to React", progress: 65, category: "Web Development" },
    { id: 2, title: "Advanced JavaScript Concepts", progress: 32, category: "Programming" },
    { id: 3, title: "UI/UX Design Fundamentals", progress: 78, category: "Design" },
  ]

  const upcomingDeadlines = [
    { id: 1, title: "React Project Submission", course: "Introduction to React", dueDate: "2023-05-20" },
    { id: 2, title: "JavaScript Quiz", course: "Advanced JavaScript Concepts", dueDate: "2023-05-18" },
  ]

  return (
    <div>
      <Title level={2}>Dashboard</Title>
      <Text type="secondary" className="block mb-6">
        Welcome back! Here's an overview of your learning progress.
      </Text>

      <Row gutter={[24, 24]}>
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false} className="shadow-sm">
            <Statistic title="Courses Enrolled" value={8} prefix={<BookOutlined />} />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false} className="shadow-sm">
            <Statistic title="Hours Spent" value={42} prefix={<ClockCircleOutlined />} />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false} className="shadow-sm">
            <Statistic title="Assignments" value={12} prefix={<TrophyOutlined />} />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card bordered={false} className="shadow-sm">
            <Statistic title="Upcoming Events" value={3} prefix={<CalendarOutlined />} />
          </Card>
        </Col>
      </Row>

      <Row gutter={[24, 24]} className="mt-6">
        <Col xs={24} lg={16}>
          <Card title="In Progress Courses" bordered={false} className="shadow-sm">
            <List
              itemLayout="horizontal"
              dataSource={inProgressCourses}
              renderItem={(item) => (
                <List.Item>
                  <List.Item.Meta
                    title={<a href={`/course/${item.id}`}>{item.title}</a>}
                    description={
                      <div>
                        <Tag color="blue">{item.category}</Tag>
                        <div className="mt-2">
                          <Progress percent={item.progress} status="active" />
                        </div>
                      </div>
                    }
                  />
                </List.Item>
              )}
            />
          </Card>
        </Col>
        <Col xs={24} lg={8}>
          <Card title="Upcoming Deadlines" bordered={false} className="shadow-sm">
            <List
              itemLayout="vertical"
              dataSource={upcomingDeadlines}
              renderItem={(item) => (
                <List.Item>
                  <div>
                    <Text strong>{item.title}</Text>
                    <div className="text-sm text-gray-500">
                      <div>{item.course}</div>
                      <div className="flex items-center mt-1">
                        <CalendarOutlined className="mr-1" />
                        Due: {new Date(item.dueDate).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </List.Item>
              )}
            />
          </Card>
        </Col>
      </Row>
    </div>
  )
}

export default Dashboard
