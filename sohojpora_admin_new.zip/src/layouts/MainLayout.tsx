"use client";

import type React from "react";
import { useState, type PropsWithChildren } from "react";
import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  DashboardOutlined,
  BookOutlined,
  ReadOutlined,
  CalendarOutlined,
  UserOutlined,
  TrophyOutlined,
  BellOutlined,
  SettingOutlined,
} from "@ant-design/icons";
import {
  Avatar,
  Badge,
  Button,
  Dropdown,
  Layout,
  Menu,
  Typography,
  theme,
  type MenuProps,
} from "antd";
import { useNavigate, type RoutesProps } from "react-router-dom";

const { Header, Sider, Content, Footer } = Layout;
const { Title } = Typography;

const MainLayout: React.FC = ({ children }: RoutesProps) => {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const {
    token: { colorBgContainer, borderRadiusLG, colorPrimary },
  } = theme.useToken();

  const items: MenuProps["items"] = [
    {
      key: "1",
      label: "My Account",
      disabled: true,
    },
    {
      type: "divider",
    },
    {
      key: "2",
      label: "Profile",
      extra: "⌘P",
    },
    {
      key: "3",
      label: "Billing",
      extra: "⌘B",
    },
    {
      key: "4",
      label: "Settings",
      icon: <SettingOutlined />,
      extra: "⌘S",
    },
  ];

  return (
    <Layout className="min-h-screen">
      <Sider
        trigger={null}
        collapsible
        collapsed={collapsed}
        className="shadow-lg"
        width={260}
        style={{
          background: colorPrimary,
          overflow: "auto",
          height: "100vh",
          position: "fixed",
          left: 0,
          top: 0,
          bottom: 0,
        }}
      >
        <div className="p-4 flex items-center justify-center">
          {!collapsed && (
            <Title level={3} className="m-0 text-white">
              Sohoj Pora
            </Title>
          )}
          {collapsed && (
            <Title level={4} className="m-0 text-white">
              S
            </Title>
          )}
        </div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={["1"]}
          style={{ background: colorPrimary }}
          onClick={(e) => {
            navigate("/" + e.key);
          }}
          items={[
            {
              key: "dashboard",
              icon: <DashboardOutlined />,
              label: "Dashboard",
            },
            {
              key: "my-courses",
              icon: <BookOutlined />,
              label: "My Courses",
            },
            {
              key: "course-catalog",
              icon: <ReadOutlined />,
              label: "Course Catalog",
            },
            {
              key: "assignments",
              icon: <TrophyOutlined />,
              label: "Assignments",
            },
            {
              key: "calendar",
              icon: <CalendarOutlined />,
              label: "Calendar",
            },
            {
              key: "profile",
              icon: <UserOutlined />,
              label: "Profile",
            },
            {
              key: "settings",
              icon: <SettingOutlined />,
              label: "Settings",
            },
          ]}
        />
      </Sider>
      <Layout
        style={{ marginLeft: collapsed ? 80 : 260, transition: "all 0.2s" }}
      >
        <Header
          style={{
            padding: "0 24px",
            background: colorBgContainer,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            boxShadow: "0 1px 4px rgba(0,0,0,0.1)",
            position: "sticky",
            top: 0,
            zIndex: 1,
          }}
        >
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{
              fontSize: "16px",
              width: 64,
              height: 64,
            }}
          />
          <div className="flex items-center gap-4">
            <Badge count={5} dot>
              <BellOutlined style={{ fontSize: "20px", cursor: "pointer" }} />
            </Badge>

            <Dropdown menu={{ items }}>
              <a onClick={(e) => e.preventDefault()}>
                <Avatar style={{ backgroundColor: colorPrimary }}>
                  <UserOutlined />
                </Avatar>
              </a>
            </Dropdown>
          </div>
        </Header>
        <Content
          style={{
            margin: "24px",
            padding: 24,
            minHeight: 280,
            background: colorBgContainer,
            borderRadius: borderRadiusLG,
          }}
        >
          {children}
        </Content>
        <Footer style={{ textAlign: "center" }}>
          EduLearn LMS ©{new Date().getFullYear()} Created by Sohojpora
        </Footer>
      </Layout>
    </Layout>
  );
};

export default MainLayout;
